#ifndef _JDqi_H
#define _JDqi_H

#include "main.h"

#define JD1	PBout(9)	//
#define JD4	PBout(13)
#define JD3	PBout(15)
#define JD2	PCout(7)

void JD_GPIO_Init(void);
#endif

