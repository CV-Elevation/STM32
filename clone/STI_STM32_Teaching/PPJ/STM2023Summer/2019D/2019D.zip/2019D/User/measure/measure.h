#ifndef _MEASURE_H
#define _MEASURE_H

#include "main.h"

void general_measure(bool i1,bool i3, bool i4);
void oneKgain(void);
void InputResistor(void);
void outputResistor(void);

#endif
