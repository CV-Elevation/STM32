#ifndef _COUNT_H
#define _COUNT_H

#include "main.h"
float singlesaopin(uint8_t channel,uint8_t readfre,int maga, int mod);
void QuickSort(uint16_t arr[], int low, int high);
void zhendesaop(void);

	
#endif

