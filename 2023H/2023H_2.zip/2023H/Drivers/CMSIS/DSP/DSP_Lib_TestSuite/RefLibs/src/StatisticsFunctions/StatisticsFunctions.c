
#include "max.c"
#include "mean.c"
#include "min.c"
#include "power.c"
#include "rms.c"
#include "std.c"
#include "var.c"
